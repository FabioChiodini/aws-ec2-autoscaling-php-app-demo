<?php include "templates/header.php"; ?>

<ul>
	<li><a href="create.php"><strong>Create</strong></a> - add a user</li>
	<li><a href="read.php"><strong>Read</strong></a> - find a user</li>
</ul>

<?php include "templates/footer.php"; ?>